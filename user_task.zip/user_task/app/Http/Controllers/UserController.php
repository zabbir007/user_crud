<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
if (!isset($_SESSION)) {
    session_start();
}
class UserController extends Controller
{

//sign up Start
	public function signup(Request $request)
     {

         $check = $this->checkCusEmailPhone($request->userEmail, $request->userPhone);
         if ($check == 1) {
            return $this->returnJson(self::$checkState, 'signup', null);
        } else if ($check == 2) {
            return $this->returnJson(self::$checkState, 'signup', null);
        } else {

        	$data=array();
	        $data['userName']=$request->userName;
	        $data['userEmail']=$request->userEmail;
	        $data['userPhone']=$request->userPhone;
	        $data['userPassword']=md5($request->userPassword);
	        $userInfo=DB::table('users')
	                      ->insert($data);
	        if ($userInfo) {
	        	return $this->returnJson("success", 'userInfo', $userInfo);
	        }else{
	        	return $this->returnJson("failed", 'userInfo', null);
	        }
	        
        }
     }
 
//sign up End

// Check Email and Phone
    private function checkCusEmailPhone($email, $phone)
    {

        $userEmail = Customer::where('userEmail', $email)
                               ->first();
        if (isset($userEmail->userEmail)) {

            if ($userEmail->verify == 0) {
                self::$checkState = "Email already registered! Please verify email while login";
                return 2;
            } else {
                self::$checkState = "Email already registered! Please Login";
                return 1;
            }
        }

        $userPhone = Customer::where('userPhone', $phone)
                               ->first();

        if (isset($userPhone->userPhone)) {

            if ($userPhone->verify == 0) {
                self::$checkState = "Number already registered!";
                return 2;
            } else {
                self::$checkState = "Phone already registered! Please Login";
                return 1;
            }
        }

        return 0;

    }

//End Check Email and Phone

//sign in here..
    public function signIn(Request $request)
    {
        $email = $request->userEmail;
        $password = md5($request->userPassword);
        $userInfo = DB::table('users')
	    				->where('userEmail', $email)
	    				->where('userPassword', $password)
	    				->first();
	    if ($userInfo) {
	        	return $this->returnJson("success", 'userInfo', $userInfo);
	        }else{
	        	return $this->returnJson("failed", 'userInfo', null);
	        }
    }

    private function returnJson($status, $objname, $data)
    {
        $info = array(
            'status' => $status,
            $objname => $data
        );
        return response()->json($info);
    }
}
